Ext.define('TodoTask.store.Tasks', {
    extend: 'Ext.data.Store',
    alias: 'store.tasks',

    model: 'TodoTask.model.Task',
    autoLoad: true,
    storeId: 'Tasks',

    data: [
        // Примерные задачи для демонстрации
        { id: 1, title: 'Позвонить клиенту', description: 'Обсудить детали сделки', dueDate: new Date(), status: 'new', type: 'today' },
        { id: 2, title: 'Составить отчет', description: 'Финансовый отчет за месяц', dueDate: new Date(), status: 'in progress', type: 'work' },
        { id: 3, title: 'План на завтра', description: 'Подготовить задачи на завтра', dueDate: Ext.Date.add(new Date(), Ext.Date.DAY, 1), status: 'new', type: 'today' }
    ]
    // В реальном приложении можно подключить proxy для работы с сервером
}); 