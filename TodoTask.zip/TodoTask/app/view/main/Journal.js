Ext.define('TodoTask.view.main.Journal', {
    extend: 'Ext.panel.Panel',
    xtype: 'journalview',
    title: 'Ежедневник',
    items: [
        {
            xtype: 'textareafield',
            grow: true,
            anchor: '100%',
            height: 400,
            emptyText: 'Пишите свои заметки здесь...'
        }
    ],
    bodyPadding: 20
    // Здесь будет большая текстовая область для заметок
}); 