Ext.define('TodoTask.view.main.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main',

    /*
    Контроллер слушает выбор пункта меню в Sidebar и меняет содержимое mainContent
    */

    init: function(view) {
        // Получаем ссылку на Sidebar и навигационное меню
        var sidebar = view.down('sidebar'),
            menu = sidebar.down('#mainMenu');

        // Слушаем выбор пункта меню
        menu.on('selectionchange', this.onMenuSelect, this);
    },

    onMenuSelect: function(tree, record) {
        if (!record) return;
        var viewName = record.get('view');
        var mainContent = this.lookupMainContent();
        if (!mainContent) return;

        // Удаляем старый компонент
        mainContent.removeAll(true);

        // Вставляем нужный view по выбору
        if (viewName === 'today') {
            mainContent.add({ xtype: 'todayview' });
        } else if (viewName === 'journal') {
            mainContent.add({ xtype: 'journalview' });
        } else if (viewName === 'worktasks') {
            mainContent.add({ xtype: 'worktasksview' });
        }
    },

    lookupMainContent: function() {
        // Находим панель mainContent
        return this.getView().down('#mainContent');
    }

    /*
    - init: подписывается на выбор меню
    - onMenuSelect: меняет содержимое mainContent
    - lookupMainContent: утилита для поиска панели
    */
}); 