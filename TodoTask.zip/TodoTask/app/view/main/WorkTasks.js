Ext.define('TodoTask.view.main.WorkTasks', {
    extend: 'Ext.panel.Panel',
    xtype: 'worktasksview',
    title: 'Рабочие задачи',
    layout: 'hbox',
    bodyPadding: 20,
    requires: [
        'Ext.grid.Panel',
        'TodoTask.store.Tasks'
    ],
    defaults: {
        flex: 1,
        height: 400,
        margin: '0 20 0 0'
    },
    dockedItems: [
        {
            xtype: 'form',
            dock: 'top',
            bodyPadding: 10,
            layout: 'hbox',
            defaults: { margin: '0 10 0 0' },
            items: [
                {
                    xtype: 'textfield',
                    name: 'title',
                    fieldLabel: 'Название',
                    allowBlank: false
                },
                {
                    xtype: 'textfield',
                    name: 'description',
                    fieldLabel: 'Описание',
                    flex: 1
                },
                {
                    xtype: 'button',
                    text: 'Добавить',
                    formBind: true,
                    handler: function(btn) {
                        var form = btn.up('form').getForm();
                        if (form.isValid()) {
                            var values = form.getValues();
                            var store = Ext.getStore('Tasks');
                            store.add({
                                id: store.max('id') + 1 || 1000,
                                title: values.title,
                                description: values.description,
                                dueDate: new Date(),
                                status: 'new',
                                type: 'work'
                            });
                            form.reset();
                        }
                    }
                }
            ]
        }
    ],
    items: [
        {
            xtype: 'grid',
            title: 'Новые',
            itemId: 'newTasks',
            store: {
                type: 'tasks',
                filters: [
                    function(rec) {
                        return rec.get('type') === 'work' && rec.get('status') === 'new';
                    }
                ]
            },
            columns: [
                { text: 'Название', dataIndex: 'title', flex: 1 },
                { text: 'Описание', dataIndex: 'description', flex: 2 },
                {
                    xtype: 'actioncolumn',
                    width: 40,
                    items: [{
                        iconCls: 'x-fa fa-trash',
                        tooltip: 'Удалить',
                        handler: function(grid, rowIndex, colIndex) {
                            var rec = grid.getStore().getAt(rowIndex);
                            Ext.Msg.confirm('Удаление', 'Удалить задачу?', function(choice) {
                                if (choice === 'yes') {
                                    grid.getStore().remove(rec);
                                }
                            });
                        }
                    }]
                }
            ],
            viewConfig: {
                plugins: {
                    gridviewdragdrop: {
                        dragText: 'Перетащите задачу в другой статус'
                    }
                },
                listeners: {
                    drop: function(node, data, dropRec, dropPosition) {
                        data.records.forEach(function(rec) {
                            rec.set('status', 'in progress');
                        });
                    }
                }
            },
            emptyText: 'Нет новых задач'
        },
        {
            xtype: 'grid',
            title: 'В работе',
            itemId: 'inProgressTasks',
            store: {
                type: 'tasks',
                filters: [
                    function(rec) {
                        return rec.get('type') === 'work' && rec.get('status') === 'in progress';
                    }
                ]
            },
            columns: [
                { text: 'Название', dataIndex: 'title', flex: 1 },
                { text: 'Описание', dataIndex: 'description', flex: 2 },
                {
                    xtype: 'actioncolumn',
                    width: 40,
                    items: [{
                        iconCls: 'x-fa fa-trash',
                        tooltip: 'Удалить',
                        handler: function(grid, rowIndex, colIndex) {
                            var rec = grid.getStore().getAt(rowIndex);
                            Ext.Msg.confirm('Удаление', 'Удалить задачу?', function(choice) {
                                if (choice === 'yes') {
                                    grid.getStore().remove(rec);
                                }
                            });
                        }
                    }]
                }
            ],
            viewConfig: {
                plugins: {
                    gridviewdragdrop: {
                        dragText: 'Перетащите задачу в другой статус'
                    }
                },
                listeners: {
                    drop: function(node, data, dropRec, dropPosition) {
                        data.records.forEach(function(rec) {
                            rec.set('status', 'done');
                        });
                    }
                }
            },
            emptyText: 'Нет задач в работе'
        },
        {
            xtype: 'grid',
            title: 'Выполнено',
            itemId: 'doneTasks',
            store: {
                type: 'tasks',
                filters: [
                    function(rec) {
                        return rec.get('type') === 'work' && rec.get('status') === 'done';
                    }
                ]
            },
            columns: [
                { text: 'Название', dataIndex: 'title', flex: 1 },
                { text: 'Описание', dataIndex: 'description', flex: 2 },
                {
                    xtype: 'actioncolumn',
                    width: 40,
                    items: [{
                        iconCls: 'x-fa fa-trash',
                        tooltip: 'Удалить',
                        handler: function(grid, rowIndex, colIndex) {
                            var rec = grid.getStore().getAt(rowIndex);
                            Ext.Msg.confirm('Удаление', 'Удалить задачу?', function(choice) {
                                if (choice === 'yes') {
                                    grid.getStore().remove(rec);
                                }
                            });
                        }
                    }]
                }
            ],
            viewConfig: {
                plugins: {
                    gridviewdragdrop: {
                        dragText: 'Перетащите задачу в другой статус'
                    }
                }
            },
            emptyText: 'Нет выполненных задач'
        }
    ]
    /*
    - Три грида: новые, в работе, выполнено
    - Drag-and-drop между гридом "Новые" и "В работе", "В работе" и "Выполнено"
    - Перетаскивание меняет статус задачи
    */
}); 