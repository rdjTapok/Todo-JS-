Ext.define('TodoTask.view.main.Today', {
    extend: 'Ext.panel.Panel',
    xtype: 'todayview',
    title: 'Сегодня',
    layout: 'vbox',
    bodyPadding: 20,
    requires: [
        'Ext.grid.Panel',
        'TodoTask.store.Tasks'
    ],
    items: [
        {
            xtype: 'grid',
            title: 'Задачи на сегодня',
            flex: 1,
            width: '100%',
            margin: '0 0 20 0',
            store: {
                type: 'tasks',
                filters: [
                    function(rec) {
                        // Фильтруем задачи на сегодня
                        var today = Ext.Date.clearTime(new Date());
                        return rec.get('type') === 'today' && Ext.Date.isEqual(Ext.Date.clearTime(rec.get('dueDate')), today);
                    }
                ]
            },
            columns: [
                { text: 'Название', dataIndex: 'title', flex: 1 },
                { text: 'Описание', dataIndex: 'description', flex: 2 },
                { text: 'Статус', dataIndex: 'status', width: 120 }
            ],
            emptyText: 'Нет задач на сегодня'
        },
        {
            xtype: 'grid',
            title: 'Ожидаемые на завтра',
            flex: 1,
            width: '100%',
            store: {
                type: 'tasks',
                filters: [
                    function(rec) {
                        // Фильтруем задачи на завтра
                        var tomorrow = Ext.Date.add(Ext.Date.clearTime(new Date()), Ext.Date.DAY, 1);
                        return rec.get('type') === 'today' && Ext.Date.isEqual(Ext.Date.clearTime(rec.get('dueDate')), tomorrow);
                    }
                ]
            },
            columns: [
                { text: 'Название', dataIndex: 'title', flex: 1 },
                { text: 'Описание', dataIndex: 'description', flex: 2 },
                { text: 'Статус', dataIndex: 'status', width: 120 }
            ],
            emptyText: 'Нет задач на завтра'
        }
    ]
    /*
    - Первый grid: задачи на сегодня
    - Второй grid: задачи на завтра
    - Используется store Tasks с фильтрацией по дате
    */
}); 