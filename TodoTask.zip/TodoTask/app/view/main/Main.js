Ext.define('TodoTask.view.main.Main', {
    extend: 'Ext.container.Viewport',
    xtype: 'app-main',

    requires: [
        'TodoTask.view.main.Sidebar',
        'Ext.panel.Panel'
    ],

    layout: {
        type: 'hbox',
        align: 'stretch'
    },

    items: [
        {
            xtype: 'sidebar', // Левая панель с логотипом и навигацией
            width: 250
        },
        {
            xtype: 'panel', // Центральная рабочая область
            flex: 1,
            itemId: 'mainContent',
            layout: 'fit',
            bodyPadding: 10,
            // Здесь будет динамически меняться содержимое в зависимости от выбранного раздела
        }
    ],
    controller: 'main', // Подключаем контроллер
    listeners: {
        afterrender: function(view) {
            // При запуске сразу показываем Today
            var mainContent = view.down('#mainContent');
            if (mainContent) {
                mainContent.removeAll(true);
                mainContent.add({ xtype: 'todayview' });
            }
        }
    },
    
    /*
    Подробности:
    - Viewport занимает всё окно браузера
    - Sidebar слева, mainContent справа
    - Контент mainContent будет меняться через контроллер
    */
}); 