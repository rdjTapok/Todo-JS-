Ext.define('TodoTask.view.main.Sidebar', {
    extend: 'Ext.panel.Panel',
    xtype: 'sidebar',

    requires: [
        'Ext.list.Tree'
    ],

    layout: {
        type: 'vbox',
        align: 'stretch'
    },
    bodyPadding: 10,
    title: '<i class="x-fa fa-list"></i> TodoTask', // Логотип/название с иконкой
    titleAlign: 'left',
    header: {
        height: 60
    },
    items: [
        {
            xtype: 'treelist',
            itemId: 'mainMenu',
            ui: 'nav',
            expanderFirst: false,
            expanderOnly: false,
            store: {
                root: {
                    expanded: true,
                    children: [
                        { text: 'Сегодня', iconCls: 'x-fa fa-calendar-day', leaf: true, view: 'today' },
                        { text: 'Ежедневник', iconCls: 'x-fa fa-book', leaf: true, view: 'journal' },
                        { text: 'Рабочие задачи', iconCls: 'x-fa fa-tasks', leaf: true, view: 'worktasks' }
                    ]
                }
            }
        }
    ]
    /*
    Подробности:
    - Верхняя часть: логотип/название
    - Ниже: навигация через Ext.list.Tree
    - При выборе пункта меню будет меняться содержимое mainContent
    */
}); 