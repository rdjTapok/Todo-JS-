Ext.define('TodoTask.model.Task', {
    extend: 'Ext.data.Model',
    alias: 'model.task',

    fields: [
        { name: 'id', type: 'int' }, // Уникальный идентификатор
        { name: 'title', type: 'string' }, // Краткое название задачи
        { name: 'description', type: 'string' }, // Описание задачи
        { name: 'dueDate', type: 'date', dateFormat: 'Y-m-d' }, // Дата выполнения
        { name: 'status', type: 'string' }, // Статус (новая, выполнена и т.д.)
        { name: 'type', type: 'string' } // today, journal, work
    ]
    /*
    Пример использования:
    - type: 'today' — задача на сегодня/завтра
    - type: 'work' — рабочая задача
    - type: 'journal' — заметка в ежедневнике
    */
}); 